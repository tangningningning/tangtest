#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""统一项目配置读取、override、校验和稳定 hash。

本文件只处理配置，不放业务算法逻辑。Python 3.11+ 使用标准库 tomllib；
若运行环境低于 3.11，则尝试使用轻量 tomli。
"""

from __future__ import annotations

import copy
import hashlib
import json
import math
from pathlib import Path
from typing import Any

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - only for Python < 3.11
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ModuleNotFoundError:
        from pip._vendor import tomli as tomllib  # type: ignore[no-redef]


def find_project_root() -> Path:
    candidates = (Path(__file__).resolve().parents[2], Path.cwd().resolve())
    for candidate in candidates:
        if (candidate / "system_config.toml").is_file() and (candidate / "data").is_dir():
            return candidate
    raise FileNotFoundError("无法找到包含 system_config.toml 的项目根目录。")


def resolve_path(project_root: Path, value: str | Path) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = project_root / path
    return path.resolve(strict=False)


def load_config(path: str | Path = "system_config.toml") -> dict[str, Any]:
    project_root = find_project_root()
    config_path = resolve_path(project_root, path)
    with config_path.open("rb") as stream:
        config = tomllib.load(stream)
    if not isinstance(config, dict):
        raise ValueError("system_config.toml 根对象必须是 table。")
    config["_meta"] = {
        "config_path": str(config_path),
        "project_root": str(project_root),
    }
    validate_config(config)
    return config


def get_config_value(config: dict[str, Any], dotted_key: str, default: Any = None) -> Any:
    current: Any = config
    for part in dotted_key.split("."):
        if not isinstance(current, dict) or part not in current:
            return default
        current = current[part]
    return current


def _node_positions_path(config: dict[str, Any]) -> Path:
    project_root = Path(
        config.get("_meta", {}).get("project_root", find_project_root())
    )
    value = get_config_value(config, "paths.node_positions")
    if not value:
        raise ValueError("缺少路径配置：paths.node_positions")
    return resolve_path(project_root, value)


def _normalise_node_position(node_id: str, value: Any) -> list[float]:
    """兼容旧数组格式，并读取新 JSON 中的 position 字段。"""

    if isinstance(value, dict):
        value = value.get("position")
    if not isinstance(value, list) or len(value) != 3:
        raise ValueError(
            f"node_positions.json 的 {node_id} 位置必须是 [x, y, z]。"
        )
    try:
        position = [float(component) for component in value]
    except (TypeError, ValueError) as exc:
        raise ValueError(
            f"node_positions.json 的 {node_id} 位置必须全部是数值。"
        ) from exc
    if not all(math.isfinite(component) for component in position):
        raise ValueError(f"node_positions.json 的 {node_id} 位置不能是 NaN/Inf。")
    return position


def load_node_positions(config: dict[str, Any]) -> dict[str, Any]:
    """读取并校验由 scenario.node_placement 生成的节点位置文件。"""

    positions_path = _node_positions_path(config)
    with positions_path.open("r", encoding="utf-8") as stream:
        payload = json.load(stream)
    if not isinstance(payload, dict):
        raise ValueError("node_positions.json 根对象必须是 object。")

    raw_boundary = payload.get("network_boundary")
    if not isinstance(raw_boundary, dict):
        network_metadata = payload.get("network")
        if isinstance(network_metadata, dict):
            raw_boundary = network_metadata.get("boundary")
    if not isinstance(raw_boundary, dict):
        raise ValueError("node_positions.json 缺少 network_boundary。")
    required_boundary_keys = ("min_x", "max_x", "min_y", "max_y")
    if any(key not in raw_boundary for key in required_boundary_keys):
        raise ValueError(
            "node_positions.json 的 network_boundary 必须包含 min_x/max_x/min_y/max_y。"
        )
    boundary = {
        key: float(raw_boundary[key])
        for key in required_boundary_keys
    }
    if not all(math.isfinite(value) for value in boundary.values()):
        raise ValueError("node_positions.json 的 network_boundary 不能是 NaN/Inf。")
    if boundary["min_x"] >= boundary["max_x"] or boundary["min_y"] >= boundary["max_y"]:
        raise ValueError("node_positions.json 的 network_boundary 非法。")

    positions: dict[str, Any] = {"network_boundary": boundary}
    for role in ("rsu", "uav"):
        raw_nodes = payload.get(role)
        if not isinstance(raw_nodes, dict):
            raise ValueError(f"node_positions.json 缺少 {role} 节点位置表。")
        normalised: dict[str, list[float]] = {}
        for raw_id, raw_position in raw_nodes.items():
            node_id = str(raw_id)
            position = _normalise_node_position(node_id, raw_position)
            x, y = position[:2]
            if not (
                boundary["min_x"] <= x <= boundary["max_x"]
                and boundary["min_y"] <= y <= boundary["max_y"]
            ):
                raise ValueError(f"{node_id} 坐标超出 SUMO 路网区域：{position}")
            normalised[node_id] = position
        positions[role] = normalised
    return positions


def _materialise_node_instances(config: dict[str, Any]) -> None:
    """将 JSON 位置转换为现有模块使用的 nodes.*.instances 结构。"""

    positions = load_node_positions(config)
    nodes = config.get("nodes")
    if not isinstance(nodes, dict):
        raise ValueError("缺少 nodes 配置表。")

    for role, prefix, x_key, y_key, z_key, altitude_key in (
        ("rsu", "RSU", "x_m", "y_m", "z_m", "deployment_altitude_m"),
        (
            "uav",
            "UAV",
            "initial_x_m",
            "initial_y_m",
            "initial_z_m",
            "deployment_altitude_m",
        ),
    ):
        count_value = get_config_value(config, f"nodes.{role}.count")
        if (
            count_value is None
            or isinstance(count_value, bool)
            or int(count_value) != count_value
            or int(count_value) < 1
        ):
            raise ValueError(f"nodes.{role}.count 必须是正整数。")
        count = int(count_value)
        expected_ids = [f"{prefix}_{index}" for index in range(count)]
        role_positions = positions[role]
        if set(role_positions) != set(expected_ids):
            raise ValueError(
                f"node_positions.json 的 {role} IDs 必须与 nodes.{role}.count 一致。"
            )
        instances = []
        expected_altitude = get_config_value(
            config,
            f"nodes.{role}.{altitude_key}",
        )
        if expected_altitude is None:
            raise ValueError(f"缺少配置项：nodes.{role}.{altitude_key}")
        expected_altitude = float(expected_altitude)
        for node_id in expected_ids:
            x, y, z = role_positions[node_id]
            if not math.isclose(z, expected_altitude, rel_tol=0.0, abs_tol=1e-9):
                raise ValueError(
                    f"{node_id} 高度 {z} 与配置 nodes.{role}.{altitude_key} "
                    f"={expected_altitude} 不一致。"
                )
            instances.append(
                {
                    "id": node_id,
                    x_key: x,
                    y_key: y,
                    z_key: z,
                }
            )
        node_config = nodes.get(role)
        if not isinstance(node_config, dict):
            raise ValueError(f"缺少 nodes.{role} 配置表。")
        node_config["instances"] = instances


def parse_override_value(raw: str) -> Any:
    lowered = raw.strip().lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    try:
        return int(raw)
    except ValueError:
        pass
    try:
        return float(raw)
    except ValueError:
        pass
    if (raw.startswith('"') and raw.endswith('"')) or (raw.startswith("'") and raw.endswith("'")):
        return raw[1:-1]
    return raw


def apply_overrides(config: dict[str, Any], overrides: list[str] | None) -> dict[str, Any]:
    updated = copy.deepcopy(config)
    if not overrides:
        validate_config(updated)
        return updated
    for override in overrides:
        if "=" not in override:
            raise ValueError(f"--set override 必须形如 a.b=value：{override}")
        dotted_key, raw_value = override.split("=", 1)
        parts = [part.strip() for part in dotted_key.split(".") if part.strip()]
        if not parts:
            raise ValueError(f"override key 为空：{override}")
        current: Any = updated
        for part in parts[:-1]:
            if part not in current or not isinstance(current[part], dict):
                raise KeyError(f"override 路径不存在或不是 table：{'.'.join(parts[:-1])}")
            current = current[part]
        leaf = parts[-1]
        if leaf not in current:
            raise KeyError(f"override key 不存在：{dotted_key}")
        old_value = current[leaf]
        new_value = parse_override_value(raw_value)
        if old_value is not None and not isinstance(new_value, type(old_value)):
            if isinstance(old_value, float) and isinstance(new_value, int):
                new_value = float(new_value)
            elif isinstance(old_value, int) and isinstance(new_value, float) and new_value.is_integer():
                new_value = int(new_value)
            else:
                raise TypeError(
                    f"override {dotted_key} 类型不匹配：原类型 {type(old_value).__name__}，"
                    f"新类型 {type(new_value).__name__}"
                )
        current[leaf] = new_value
    validate_config(updated)
    return updated


def config_hash(config: dict[str, Any]) -> str:
    canonical = copy.deepcopy(config)
    canonical.pop("_meta", None)
    payload = json.dumps(
        canonical,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def get_parameter_status(config: dict[str, Any], dotted_key: str) -> str | None:
    statuses = config.get("parameter_status", {})
    value = statuses.get(dotted_key)
    return str(value) if value is not None else None


def list_unresolved_parameters(config: dict[str, Any]) -> dict[str, str]:
    statuses = config.get("parameter_status", {})
    allowed = {
        "CONFIRMED_DATA",
        "TRAIN_ONLY_CALIBRATION",
        "EXPERIMENT_DESIGN",
        "ALGORITHM_DESIGN",
        "LITERATURE_DERIVED",
        "PROVISIONAL_IMPLEMENTATION",
        "TODO_LITERATURE_CALIBRATION",
    }
    unresolved: dict[str, str] = {}
    for key, value in statuses.items():
        status = str(value)
        if status not in allowed:
            raise ValueError(f"未知参数状态 {status}：{key}")
        if status in {"PROVISIONAL_IMPLEMENTATION", "TODO_LITERATURE_CALIBRATION"}:
            unresolved[str(key)] = status
    return unresolved


# 只把真正影响系统物理模型、约束和正式目标函数的参数纳入 formal status gate。
# 算法超参数（如 local search 轮数/容差、surrogate range cutoff）仍由 validate_config()
# 检查类型和取值范围，但不要求伪装成“文献物理校准参数”。
FORMAL_SYSTEM_PARAMETER_KEYS = {
    "simulation.dt_s",
    "execution.cross_slot_task_model",
    "simulation.warmup_time_s",
    "simulation.episode_time_s",
    "simulation.num_research_vehicles",
    "simulation.num_task_vehicles",
    "simulation.num_service_vehicles",
    "service.count",
    "service.catalog_path",
    "service.generation.service_size_min_gb",
    "service.generation.service_size_max_gb",
    "service.generation.input_size_min_kb",
    "service.generation.input_size_max_kb",
    "service.generation.cycles_per_bit_min",
    "service.generation.cycles_per_bit_max",
    "task.arrival_probability",
    "task.popularity_zeta",
    "task.popularity_epoch_length",
    "task.popularity_changes_per_epoch",
    "task.input_relative_jitter",
    "task.load_relative_jitter",
    "task.master_seed",
    "nodes.sv.cache_capacity_mb",
    "nodes.rsu.count",
    "nodes.rsu.cache_capacity_mb",
    "nodes.uav.count",
    "nodes.uav.cache_capacity_mb",
    "nodes.sv.eta_ca",
    "nodes.rsu.eta_ca",
    "nodes.uav.eta_ca",
    "nodes.sv.xi_ca",
    "nodes.rsu.xi_ca",
    "nodes.uav.xi_ca",
    "nodes.vehicle.local_cpu_cycles_per_s",
    "nodes.vehicle.local_cache_capacity_mb",
    "nodes.vehicle.kappa",
    "nodes.vehicle.transmit_power_w",
    "nodes.sv.cpu_cycles_per_s",
    "nodes.rsu.cpu_cycles_per_s",
    "nodes.uav.cpu_cycles_per_s",
    "nodes.cloud.cpu_cycles_per_s",
    "nodes.cloud.total_cpu_cycles_per_s",
    "nodes.cloud.uplink_rate_bps",
    "nodes.cloud.total_bandwidth_bps",
    "nodes.cloud.resource_sharing",
    "nodes.cloud.cloud_delay_factor",
    "nodes.sv.bandwidth_hz",
    "nodes.rsu.bandwidth_hz",
    "nodes.uav.bandwidth_hz",
    "nodes.uav.altitude_m",
    "nodes.uav.deployment_altitude_m",
    "nodes.uav.max_horizontal_speed_mps",
    "nodes.uav.min_safety_distance_m",
    "nodes.uav.movement.movement_energy_coefficient_j_per_m",
    "nodes.uav.movement.movement_fixed_cost",
    "communication.ground.channel_gain_at_1m",
    "communication.ground.pathloss_exponent",
    "communication.ground.bandwidth_hz",
    "communication.noise.noise_power_w",
    "communication.air.eta1",
    "communication.air.eta2",
    "communication.air.carrier_frequency_hz",
    "communication.air.beta_los",
    "communication.air.beta_nlos",
    "communication.air.alpha_los",
    "communication.air.alpha_nlos",
    "communication.cloud.uplink_rate_bps",
    "objective.omega_delay",
    "objective.omega_energy",
    "objective.lambda_cache",
    "objective.lambda_movement",
    "objective.T_ref",
    "objective.E_ref",
}


def validate_for_formal_experiment(
    config: dict[str, Any],
    allow_provisional: bool = False,
) -> None:
    validate_config(config)
    unresolved = {
        key: status
        for key, status in list_unresolved_parameters(config).items()
        if key in FORMAL_SYSTEM_PARAMETER_KEYS
    }
    todo = {
        key: status
        for key, status in unresolved.items()
        if status == "TODO_LITERATURE_CALIBRATION"
    }
    provisional = {
        key: status
        for key, status in unresolved.items()
        if status == "PROVISIONAL_IMPLEMENTATION"
    }
    if todo:
        names = ", ".join(sorted(todo)[:8])
        raise ValueError(f"正式实验禁止使用尚待文献校准参数：{names}")
    if provisional and not allow_provisional:
        names = ", ".join(sorted(provisional)[:8])
        raise ValueError(
            "正式实验仍存在PROVISIONAL_IMPLEMENTATION参数；"
            f"请先校准或显式 allow_provisional=True：{names}"
        )


def _walk_numbers(value: Any, path: str = "config") -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            _walk_numbers(child, f"{path}.{key}")
    elif isinstance(value, list):
        for index, child in enumerate(value):
            _walk_numbers(child, f"{path}[{index}]")
    elif isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError(f"{path} 不能是 NaN/Inf。")


def _require_positive(config: dict[str, Any], dotted_key: str) -> None:
    value = get_config_value(config, dotted_key)
    if value is None:
        raise ValueError(f"缺少配置项：{dotted_key}")
    if float(value) <= 0.0:
        raise ValueError(f"{dotted_key} 必须大于 0。")


def _require_path_exists(config: dict[str, Any], dotted_key: str) -> None:
    project_root = Path(config["_meta"]["project_root"])
    value = get_config_value(config, dotted_key)
    if not value:
        raise ValueError(f"缺少路径配置：{dotted_key}")
    path = resolve_path(project_root, value)
    if not path.exists():
        raise FileNotFoundError(f"{dotted_key} 指向的路径不存在：{path}")


def validate_config(config: dict[str, Any]) -> None:
    project_root = Path(config.get("_meta", {}).get("project_root", find_project_root()))
    config.setdefault("_meta", {})
    config["_meta"].setdefault("project_root", str(project_root))

    _materialise_node_instances(config)
    _walk_numbers(config)

    service_count_value = get_config_value(config, "service.count")
    if (
        service_count_value is None
        or isinstance(service_count_value, bool)
        or int(service_count_value) != service_count_value
        or int(service_count_value) <= 0
    ):
        raise ValueError("service.count 必须是正整数。")
    service_generation = get_config_value(config, "service.generation")
    if not isinstance(service_generation, dict):
        raise ValueError("缺少 service.generation 配置表。")
    service_ranges = (
        ("service_size_min_gb", "service_size_max_gb", "service_size"),
        (
            "input_size_min_kb",
            "input_size_max_kb",
            "input_size",
        ),
        ("cycles_per_bit_min", "cycles_per_bit_max", "cycles_per_bit"),
    )
    for lower_key, upper_key, label in service_ranges:
        lower = service_generation.get(lower_key)
        upper = service_generation.get(upper_key)
        if lower is None or upper is None:
            raise ValueError(
                f"service.generation 缺少 {lower_key}/{upper_key}。"
            )
        lower = float(lower)
        upper = float(upper)
        if not math.isfinite(lower) or not math.isfinite(upper):
            raise ValueError(f"service.generation.{label} 范围不能是 NaN/Inf。")
        if lower <= 0.0:
            raise ValueError(f"service.generation.{lower_key} 必须大于 0。")
        if upper < lower:
            raise ValueError(
                f"service.generation.{upper_key} 必须大于等于 {lower_key}。"
            )

    uav_count = int(get_config_value(config, "nodes.uav.count"))
    if uav_count < 1:
        raise ValueError("nodes.uav.count 必须至少为1，请检查system_config.toml。")
    uav_instances = get_config_value(config, "nodes.uav.instances", [])
    if len(uav_instances) != uav_count:
        raise ValueError("nodes.uav.instances 数量必须等于 nodes.uav.count。")
    expected_uav_ids = [f"UAV_{index}" for index in range(uav_count)]
    actual_uav_ids = [str(item.get("id")) for item in uav_instances]
    if actual_uav_ids != expected_uav_ids:
        raise ValueError("UAV ID 必须按 UAV_0, UAV_1, ... 连续命名。")

    min_safety_distance_m = float(
        get_config_value(config, "nodes.uav.min_safety_distance_m")
    )
    if min_safety_distance_m <= 0.0:
        raise ValueError("nodes.uav.min_safety_distance_m 必须大于 0。")
    for left_index, left in enumerate(uav_instances):
        for right in uav_instances[left_index + 1 :]:
            distance = math.hypot(
                float(left["initial_x_m"]) - float(right["initial_x_m"]),
                float(left["initial_y_m"]) - float(right["initial_y_m"]),
            )
            if distance + 1.0e-12 < min_safety_distance_m:
                raise ValueError(
                    "UAV 初始位置违反 nodes.uav.min_safety_distance_m："
                    f"distance={distance:.12g}, required={min_safety_distance_m:.12g}。"
                )

    roles_path = resolve_path(project_root, get_config_value(config, "paths.vehicle_roles"))
    with roles_path.open("r", encoding="utf-8") as stream:
        roles = json.load(stream)
    tv = [str(value) for value in roles.get("task_vehicles", [])]
    sv = [str(value) for value in roles.get("service_vehicles", [])]
    research = [str(value) for value in roles.get("research_vehicles", [])]
    configured_research = int(
        get_config_value(config, "simulation.num_research_vehicles")
    )
    configured_sv = int(get_config_value(config, "simulation.num_service_vehicles"))
    configured_tv = int(get_config_value(config, "simulation.num_task_vehicles"))
    if (len(research), len(sv), len(tv)) != (
        configured_research,
        configured_sv,
        configured_tv,
    ):
        raise ValueError(
            "vehicle_roles.json 车辆数量必须与 system_config.toml 的正式 baseline 一致。"
        )
    if len(research) != len(set(research)) or len(sv) != len(set(sv)) or len(tv) != len(set(tv)):
        raise ValueError("vehicle_roles.json 研究车辆角色列表不能包含重复 ID。")
    if len(tv) + len(sv) != len(research) or set(tv) | set(sv) != set(research):
        raise ValueError("TV+SV数量或集合与research vehicle不一致。")

    if int(get_config_value(config, "prediction.vehicle.horizon")) < 1:
        raise ValueError("prediction.vehicle.horizon 必须 >= 1。")
    if int(get_config_value(config, "scenario.num_scenarios")) < 1:
        raise ValueError("scenario.num_scenarios 必须 >= 1。")
    if get_config_value(config, "algorithm.uav.method", "coarse_to_fine_coordinate") != (
        "coarse_to_fine_coordinate"
    ):
        raise ValueError("algorithm.uav.method 当前只支持 coarse_to_fine_coordinate。")
    if int(get_config_value(config, "algorithm.uav.coarse_num_angles")) < 4:
        raise ValueError("algorithm.uav.coarse_num_angles 必须 >= 4。")
    if int(get_config_value(config, "algorithm.uav.refine_num_angles")) < 4:
        raise ValueError("algorithm.uav.refine_num_angles 必须 >= 4。")
    if int(get_config_value(config, "algorithm.uav.refine_rounds")) < 0:
        raise ValueError("algorithm.uav.refine_rounds 不能为负。")
    if int(get_config_value(config, "algorithm.uav.max_coordinate_rounds")) < 1:
        raise ValueError("algorithm.uav.max_coordinate_rounds 必须 >= 1。")
    if float(get_config_value(config, "algorithm.uav.refine_radius_shrink")) <= 0.0:
        raise ValueError("algorithm.uav.refine_radius_shrink 必须大于 0。")
    if float(get_config_value(config, "algorithm.uav.position_tolerance_m")) < 0.0:
        raise ValueError("algorithm.uav.position_tolerance_m 不能为负。")
    if float(get_config_value(config, "algorithm.uav.objective_tolerance")) < 0.0:
        raise ValueError("algorithm.uav.objective_tolerance 不能为负。")
    radius_fractions = get_config_value(config, "algorithm.uav.coarse_radius_fractions")
    if not isinstance(radius_fractions, list) or not radius_fractions:
        raise ValueError("algorithm.uav.coarse_radius_fractions 必须是非空列表。")
    for value in radius_fractions:
        number = float(value)
        if number <= 0.0 or number > 1.0:
            raise ValueError("algorithm.uav.coarse_radius_fractions 必须位于 (0,1]。")
    if get_config_value(config, "algorithm.configuration.method", "cache_uav_coordinate") != (
        "cache_uav_coordinate"
    ):
        raise ValueError("algorithm.configuration.method 当前只支持 cache_uav_coordinate。")
    if int(get_config_value(config, "algorithm.configuration.max_outer_rounds")) < 1:
        raise ValueError("algorithm.configuration.max_outer_rounds 必须 >= 1。")
    if float(get_config_value(config, "algorithm.configuration.objective_tolerance")) < 0.0:
        raise ValueError("algorithm.configuration.objective_tolerance 不能为负。")
    min_cpu_fraction = float(get_config_value(config, "algorithm.kkt.min_cpu_fraction"))
    min_bandwidth_fraction = float(get_config_value(config, "algorithm.kkt.min_bandwidth_fraction"))
    if not 0.0 < min_cpu_fraction <= 1.0:
        raise ValueError("algorithm.kkt.min_cpu_fraction 必须位于 (0,1]。")
    if not 0.0 < min_bandwidth_fraction <= 1.0:
        raise ValueError("algorithm.kkt.min_bandwidth_fraction 必须位于 (0,1]。")
    if float(get_config_value(config, "algorithm.kkt.bisection_tolerance")) <= 0.0:
        raise ValueError("algorithm.kkt.bisection_tolerance 必须大于 0。")
    if int(get_config_value(config, "algorithm.kkt.max_bisection_iterations")) < 1:
        raise ValueError("algorithm.kkt.max_bisection_iterations 必须 >= 1。")
    if get_config_value(config, "algorithm.matching.method", "transfer_exchange") != (
        "transfer_exchange"
    ):
        raise ValueError("algorithm.matching.method 当前只支持 transfer_exchange。")
    if int(get_config_value(config, "algorithm.matching.max_updates")) < 1:
        raise ValueError("algorithm.matching.max_updates 必须 >= 1。")
    if float(get_config_value(config, "algorithm.matching.objective_tolerance")) < 0.0:
        raise ValueError("algorithm.matching.objective_tolerance 不能为负。")
    ppo_method = str(get_config_value(config, "algorithm.ppo.method", "trigger_actor_critic"))
    if ppo_method not in {
        "trigger_actor_critic",
        "proposed_per_trigger_q",
        "proposed_centralized_cf_q",
        "proposed_sparse_direct_cf_ppo",
        "proposed_sparse_direct_cf_frozen_policy_batch",
        "proposed_sparse_direct_cf_frozen_policy_batch_refdrift",
        "proposed_hierarchical_reconfiguration_gate_direct_cf_refdrift",
    }:
        raise ValueError(
            "algorithm.ppo.method 当前只支持 trigger_actor_critic、"
            "proposed_per_trigger_q、proposed_centralized_cf_q 或 "
            "proposed_sparse_direct_cf_ppo、proposed_sparse_direct_cf_frozen_policy_batch 或 "
            "proposed_sparse_direct_cf_frozen_policy_batch_refdrift 或 "
            "proposed_hierarchical_reconfiguration_gate_direct_cf_refdrift。"
        )
    credit_assignment = get_config_value(config, "algorithm.ppo.credit_assignment")
    if credit_assignment is not None and str(credit_assignment) not in {
        "legacy_scalar",
        "per_trigger_q",
        "centralized_counterfactual_q",
        "sparse_direct_cf",
        "hierarchical_gate_direct_cf",
    }:
        raise ValueError(
            "algorithm.ppo.credit_assignment 必须是 legacy_scalar、per_trigger_q "
            "centralized_counterfactual_q、sparse_direct_cf 或 "
            "hierarchical_gate_direct_cf。"
        )
    if ppo_method == "proposed_hierarchical_reconfiguration_gate_direct_cf_refdrift" and (
        credit_assignment is not None
        and str(credit_assignment) != "hierarchical_gate_direct_cf"
    ):
        raise ValueError(
            "hierarchical Gate method 必须使用 credit_assignment=hierarchical_gate_direct_cf。"
        )
    credit_phase = get_config_value(config, "algorithm.ppo.credit_phase")
    if credit_phase is not None and str(credit_phase) not in {"critic_warmup", "joint_training"}:
        raise ValueError(
            "algorithm.ppo.credit_phase 必须是 critic_warmup 或 joint_training。"
        )
    ppo_hidden_sizes = get_config_value(config, "algorithm.ppo.hidden_sizes", [])
    if not isinstance(ppo_hidden_sizes, list) or not ppo_hidden_sizes:
        raise ValueError("algorithm.ppo.hidden_sizes 必须是非空列表。")
    if any(int(value) <= 0 for value in ppo_hidden_sizes):
        raise ValueError("algorithm.ppo.hidden_sizes 必须全部为正整数。")
    if int(get_config_value(config, "algorithm.ppo.autoregressive_hidden_size")) <= 0:
        raise ValueError("algorithm.ppo.autoregressive_hidden_size 必须大于 0。")
    actor_architecture = str(
        get_config_value(
            config,
            "algorithm.ppo.actor_architecture",
            "v3_shared_logit_head",
        )
    )
    if actor_architecture not in {
        "v3_shared_logit_head",
        "v3_encoder_trigger_heads_frozen_ar_v1",
        "v3_full_shared_actor_frozen_policy_batch_v1",
    }:
        raise ValueError(
            "algorithm.ppo.actor_architecture 必须是 v3_shared_logit_head、"
            "v3_encoder_trigger_heads_frozen_ar_v1 或 "
            "v3_full_shared_actor_frozen_policy_batch_v1。"
        )
    ppo_gamma = float(get_config_value(config, "algorithm.ppo.gamma"))
    ppo_gae_lambda = float(get_config_value(config, "algorithm.ppo.gae_lambda"))
    if not 0.0 <= ppo_gamma <= 1.0:
        raise ValueError("algorithm.ppo.gamma 必须位于 [0,1]。")
    if not 0.0 <= ppo_gae_lambda <= 1.0:
        raise ValueError("algorithm.ppo.gae_lambda 必须位于 [0,1]。")
    ppo_clip_epsilon = float(get_config_value(config, "algorithm.ppo.clip_epsilon"))
    ppo_learning_rate = float(get_config_value(config, "algorithm.ppo.learning_rate"))
    ppo_value_coef = float(get_config_value(config, "algorithm.ppo.value_loss_coefficient"))
    ppo_entropy_coef = float(get_config_value(config, "algorithm.ppo.entropy_coefficient"))
    ppo_max_grad_norm = float(get_config_value(config, "algorithm.ppo.max_grad_norm"))
    ppo_update_epochs = int(get_config_value(config, "algorithm.ppo.update_epochs"))
    ppo_num_minibatches = int(get_config_value(config, "algorithm.ppo.num_minibatches"))
    if not 0.0 < ppo_clip_epsilon < 1.0:
        raise ValueError("algorithm.ppo.clip_epsilon 必须位于 (0,1)。")
    if ppo_learning_rate <= 0.0:
        raise ValueError("algorithm.ppo.learning_rate 必须大于 0。")
    if ppo_value_coef < 0.0:
        raise ValueError("algorithm.ppo.value_loss_coefficient 不能为负。")
    if ppo_entropy_coef < 0.0:
        raise ValueError("algorithm.ppo.entropy_coefficient 不能为负。")
    if ppo_max_grad_norm <= 0.0:
        raise ValueError("algorithm.ppo.max_grad_norm 必须大于 0。")
    if ppo_update_epochs < 1:
        raise ValueError("algorithm.ppo.update_epochs 必须 >= 1。")
    if ppo_num_minibatches < 1:
        raise ValueError("algorithm.ppo.num_minibatches 必须 >= 1。")
    cf_samples_per_episode = get_config_value(config, "algorithm.ppo.cf_samples_per_episode")
    if cf_samples_per_episode is not None:
        if isinstance(cf_samples_per_episode, bool) or int(cf_samples_per_episode) != cf_samples_per_episode:
            raise ValueError("algorithm.ppo.cf_samples_per_episode 必须是正整数。")
        if int(cf_samples_per_episode) <= 0:
            raise ValueError("algorithm.ppo.cf_samples_per_episode 必须是正整数。")
    cf_batch_episodes = get_config_value(config, "algorithm.ppo.cf_batch_episodes", 1)
    if isinstance(cf_batch_episodes, bool) or int(cf_batch_episodes) != cf_batch_episodes:
        raise ValueError("algorithm.ppo.cf_batch_episodes 必须是正整数。")
    if int(cf_batch_episodes) <= 0:
        raise ValueError("algorithm.ppo.cf_batch_episodes 必须是正整数。")
    cf_parallel_workers = get_config_value(config, "algorithm.ppo.cf_parallel_workers", 8)
    if isinstance(cf_parallel_workers, bool) or int(cf_parallel_workers) != cf_parallel_workers:
        raise ValueError("algorithm.ppo.cf_parallel_workers 必须是正整数。")
    if int(cf_parallel_workers) <= 0:
        raise ValueError("algorithm.ppo.cf_parallel_workers 必须是正整数。")
    prediction_batch_parallel_workers = get_config_value(
        config,
        "algorithm.configuration.prediction_batch_parallel_workers",
        1,
    )
    if (
        isinstance(prediction_batch_parallel_workers, bool)
        or int(prediction_batch_parallel_workers) != prediction_batch_parallel_workers
        or int(prediction_batch_parallel_workers) <= 0
    ):
        raise ValueError(
            "algorithm.configuration.prediction_batch_parallel_workers 必须是正整数。"
        )
    reference_drift_cap = get_config_value(config, "algorithm.ppo.reference_probability_drift_cap")
    if ppo_method in {
        "proposed_sparse_direct_cf_frozen_policy_batch_refdrift",
        "proposed_hierarchical_reconfiguration_gate_direct_cf_refdrift",
    } and reference_drift_cap is None:
        raise ValueError(
            "refdrift正式实现必须显式设置algorithm.ppo.reference_probability_drift_cap=0.005。"
        )
    if reference_drift_cap is not None:
        cap = float(reference_drift_cap)
        if not 0.0 < cap <= 1.0:
            raise ValueError(
                "algorithm.ppo.reference_probability_drift_cap 必须位于 (0,1]。"
            )
        if ppo_method in {
            "proposed_sparse_direct_cf_frozen_policy_batch_refdrift",
            "proposed_hierarchical_reconfiguration_gate_direct_cf_refdrift",
        } and cap != 0.005:
            raise ValueError(
                "refdrift正式实现固定使用reference_probability_drift_cap=0.005。"
            )
    cf_sampling_strategy = str(
        get_config_value(config, "algorithm.ppo.cf_sampling_strategy", "uniform")
    )
    if cf_sampling_strategy not in {"uniform", "trigger_stratified"}:
        raise ValueError(
            "algorithm.ppo.cf_sampling_strategy 必须是 uniform 或 trigger_stratified。"
        )
    arrival = float(get_config_value(config, "task.arrival_probability"))
    if not 0.0 <= arrival <= 1.0:
        raise ValueError("task.arrival_probability 必须位于 [0,1]。")
    if float(get_config_value(config, "task.popularity_zeta")) <= 0.0:
        raise ValueError("task.popularity_zeta 必须大于 0。")
    dt_s = float(get_config_value(config, "simulation.dt_s"))
    warmup_s = float(get_config_value(config, "simulation.warmup_time_s"))
    episode_s = float(get_config_value(config, "simulation.episode_time_s"))
    if dt_s <= 0.0 or warmup_s < 0.0 or episode_s <= 0.0:
        raise ValueError("simulation.dt_s/warmup_time_s/episode_time_s 数值范围无效。")
    if str(get_config_value(config, "execution.cross_slot_task_model")) != "independent_per_slot":
        raise ValueError(
            "execution.cross_slot_task_model 必须为 independent_per_slot。"
        )
    for label, duration in (("warmup_time_s", warmup_s), ("episode_time_s", episode_s)):
        steps = duration / dt_s
        if not math.isclose(steps, round(steps), rel_tol=0.0, abs_tol=1e-9):
            raise ValueError(f"simulation.{label} 必须是 dt_s 的整数倍。")

    # PPO 只允许一个连续 train 区间和一个紧邻的 held-out test 区间。
    # 具体边界只从 TOML 读取；这里仅校验区间关系、正式 episode 覆盖范围
    # 和当前 PPO minibatch 协议，不在代码中复制某个实验的 end index。
    data_protocol = get_config_value(config, "algorithm.ppo.data_protocol")
    if not isinstance(data_protocol, dict):
        raise ValueError("缺少 algorithm.ppo.data_protocol 配置表。")
    required_origin_keys = (
        "train_origin_start",
        "train_origin_end",
        "test_origin_start",
        "test_origin_end",
    )
    missing_origin_keys = [
        key for key in required_origin_keys if key not in data_protocol
    ]
    if missing_origin_keys:
        raise ValueError(
            "algorithm.ppo.data_protocol 缺少边界："
            f"{', '.join(missing_origin_keys)}"
        )
    origin_bounds: dict[str, int] = {}
    for key in required_origin_keys:
        value = data_protocol[key]
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError(
                f"algorithm.ppo.data_protocol.{key} 必须是整数。"
            )
        origin_bounds[key] = int(value)
    train_start = origin_bounds["train_origin_start"]
    train_end = origin_bounds["train_origin_end"]
    test_start = origin_bounds["test_origin_start"]
    test_end = origin_bounds["test_origin_end"]
    if train_start != 0:
        raise ValueError(
            "algorithm.ppo.data_protocol.train_origin_start 必须为正式 origin 的起点0。"
        )
    if train_end < train_start:
        raise ValueError("PPO train origin 区间必须非空且按升序排列。")
    if test_start != train_end + 1:
        raise ValueError(
            "PPO train/test origin 区间必须连续、无重叠且无空洞。"
        )
    if test_end < test_start:
        raise ValueError("PPO test origin 区间必须非空且按升序排列。")
    formal_origin_count = int(round(episode_s / dt_s))
    if test_end != formal_origin_count - 1:
        raise ValueError(
            "PPO train/test origin 区间必须完整覆盖正式 episode："
            f"test_origin_end={test_end}, expected={formal_origin_count - 1}。"
        )
    train_origin_count = train_end - train_start + 1
    test_origin_count = test_end - test_start + 1
    if train_origin_count < ppo_num_minibatches or train_origin_count % ppo_num_minibatches != 0:
        raise ValueError(
            "PPO train origin 数量必须为正并可被 algorithm.ppo.num_minibatches 整除："
            f"count={train_origin_count}, num_minibatches={ppo_num_minibatches}。"
        )
    if test_origin_count <= 0:
        raise ValueError("PPO test origin 数量必须大于0。")
    research_count = int(get_config_value(config, "simulation.num_research_vehicles"))
    service_count = int(get_config_value(config, "simulation.num_service_vehicles"))
    task_count = int(get_config_value(config, "simulation.num_task_vehicles"))
    if research_count <= 0 or service_count < 0 or task_count < 0:
        raise ValueError("simulation 车辆数量范围无效。")
    if service_count + task_count != research_count:
        raise ValueError("simulation SV+TV 数量必须等于 research vehicle 数量。")
    departure_begin = float(
        get_config_value(config, "simulation.random_trips_departure_begin_s", 0.0)
    )
    departure_end = float(
        get_config_value(config, "simulation.random_trips_departure_end_s", 60.0)
    )
    if departure_begin < 0.0 or departure_end <= departure_begin:
        raise ValueError("randomTrips departure begin/end 配置无效。")
    if float(get_config_value(config, "simulation.random_trips_period_s", 1.0)) <= 0.0:
        raise ValueError("simulation.random_trips_period_s 必须大于 0。")
    if float(get_config_value(config, "simulation.random_trips_min_distance_m", 0.0)) < 0.0:
        raise ValueError("simulation.random_trips_min_distance_m 不能为负数。")
    if int(get_config_value(config, "simulation.random_trips_intermediate", 0)) < 0:
        raise ValueError("simulation.random_trips_intermediate 不能为负数。")
    if int(get_config_value(config, "simulation.random_trips_maxtries", 1)) <= 0:
        raise ValueError("simulation.random_trips_maxtries 必须大于 0。")

    for key in (
        "nodes.sv.cache_capacity_mb",
        "nodes.rsu.cache_capacity_mb",
        "nodes.uav.cache_capacity_mb",
        "nodes.vehicle.local_cache_capacity_mb",
        "nodes.vehicle.local_cpu_cycles_per_s",
        "nodes.sv.cpu_cycles_per_s",
        "nodes.rsu.cpu_cycles_per_s",
        "nodes.uav.cpu_cycles_per_s",
        "nodes.cloud.cpu_cycles_per_s",
        "nodes.cloud.total_cpu_cycles_per_s",
        "nodes.cloud.total_bandwidth_bps",
        "nodes.uav.altitude_m",
        "nodes.uav.max_horizontal_speed_mps",
        "nodes.uav.min_safety_distance_m",
        "nodes.uav.movement.movement_energy_coefficient_j_per_m",
        "nodes.sv.bandwidth_hz",
        "nodes.rsu.bandwidth_hz",
        "nodes.uav.bandwidth_hz",
        "nodes.rsu.deployment_altitude_m",
        "nodes.uav.deployment_altitude_m",
        "nodes.uav.deployment_offset_fraction",
        "communication.ground.bandwidth_hz",
        "communication.air.eta1",
        "communication.air.eta2",
        "communication.air.carrier_frequency_hz",
        "communication.air.beta_los",
        "communication.air.beta_nlos",
        "communication.air.alpha_los",
        "communication.air.alpha_nlos",
    ):
        _require_positive(config, key)

    rsu_count = int(get_config_value(config, "nodes.rsu.count"))
    if rsu_count < 1:
        raise ValueError("nodes.rsu.count 必须至少为1。")
    rsu_instances = get_config_value(config, "nodes.rsu.instances", [])
    if len(rsu_instances) != rsu_count:
        raise ValueError("nodes.rsu.instances 数量必须等于 nodes.rsu.count。")
    expected_rsu_ids = [f"RSU_{index}" for index in range(rsu_count)]
    actual_rsu_ids = [str(item.get("id")) for item in rsu_instances]
    if actual_rsu_ids != expected_rsu_ids:
        raise ValueError("RSU ID 必须按 RSU_0, RSU_1, ... 连续命名。")

    omega_delay = float(get_config_value(config, "objective.omega_delay"))
    omega_energy = float(get_config_value(config, "objective.omega_energy"))
    if not 0.0 <= omega_delay <= 1.0:
        raise ValueError("objective.omega_delay 必须位于 [0,1]。")
    if not 0.0 <= omega_energy <= 1.0:
        raise ValueError("objective.omega_energy 必须位于 [0,1]。")
    if not math.isclose(omega_delay + omega_energy, 1.0, rel_tol=0.0, abs_tol=1e-12):
        raise ValueError(
            "objective.omega_delay 和 objective.omega_energy "
            "必须位于 [0,1] 且总和等于 1。"
        )
    _require_positive(config, "objective.T_ref")
    _require_positive(config, "objective.E_ref")
    cloud_delay_factor = float(get_config_value(config, "nodes.cloud.cloud_delay_factor"))
    if cloud_delay_factor < 1.0:
        raise ValueError(
            "Cloud传输扩展系数psi_c必须不小于1，"
            "因为其用于表示蜂窝接入基础上传时延之外的"
            "回传网络和核心网附加时延。"
        )
    cloud_resource_sharing = get_config_value(config, "nodes.cloud.resource_sharing")
    if not isinstance(cloud_resource_sharing, bool):
        raise ValueError(
            "nodes.cloud.resource_sharing 必须显式配置为 true/false，"
            "不允许缺失后静默采用默认共享语义。"
        )
    if cloud_resource_sharing:
        raise ValueError(
            "当前正式模型要求 nodes.cloud.resource_sharing=false；"
            "Cloud 使用固定每任务资源，不按同槽任务数均分。"
        )
    uav_deployment_altitude = float(
        get_config_value(config, "nodes.uav.deployment_altitude_m")
    )
    uav_channel_altitude = float(get_config_value(config, "nodes.uav.altitude_m"))
    if not math.isclose(
        uav_deployment_altitude,
        uav_channel_altitude,
        rel_tol=0.0,
        abs_tol=1.0e-12,
    ):
        raise ValueError(
            "nodes.uav.deployment_altitude_m 必须与 nodes.uav.altitude_m 一致，"
            "以保持 UAV 部署与通信高度的单一合同。"
        )

    # 单位/重复参数一致性：配置中统一使用 cycle/s、Hz、W、bit/s、MB。
    if float(get_config_value(config, "communication.ground.bandwidth_hz")) != float(
        get_config_value(config, "nodes.sv.bandwidth_hz")
    ):
        raise ValueError("communication.ground.bandwidth_hz 必须与 nodes.sv.bandwidth_hz 一致。")
    if float(get_config_value(config, "communication.ground.bandwidth_hz")) != float(
        get_config_value(config, "nodes.rsu.bandwidth_hz")
    ):
        raise ValueError("communication.ground.bandwidth_hz 必须与 nodes.rsu.bandwidth_hz 一致。")
    if float(get_config_value(config, "communication.cloud.uplink_rate_bps")) != float(
        get_config_value(config, "nodes.cloud.uplink_rate_bps")
    ):
        raise ValueError("communication.cloud.uplink_rate_bps 必须与 nodes.cloud.uplink_rate_bps 一致。")
    if float(get_config_value(config, "nodes.cloud.cpu_cycles_per_s")) != float(
        get_config_value(config, "nodes.cloud.total_cpu_cycles_per_s")
    ):
        raise ValueError("Cloud legacy CPU 字段必须与唯一总 CPU 容量一致。")
    if float(get_config_value(config, "nodes.cloud.uplink_rate_bps")) != float(
        get_config_value(config, "nodes.cloud.total_bandwidth_bps")
    ):
        raise ValueError("Cloud legacy uplink 字段必须与唯一总带宽容量一致。")

    for key, status in config.get("parameter_status", {}).items():
        if status not in {
            "CONFIRMED_DATA",
            "TRAIN_ONLY_CALIBRATION",
            "EXPERIMENT_DESIGN",
            "ALGORITHM_DESIGN",
            "LITERATURE_DERIVED",
            "PROVISIONAL_IMPLEMENTATION",
            "TODO_LITERATURE_CALIBRATION",
        }:
            raise ValueError(f"未知参数状态 {status}：{key}")

    for key in (
        "paths.service_catalog",
        "paths.vehicle_roles",
        "paths.prediction_scenarios",
        "paths.sumo_net",
        "paths.node_positions",
        "paths.popularity_gru",
        "paths.tv_local_cache",
    ):
        _require_path_exists(config, key)


def main() -> int:
    config = load_config()
    print("system_config.toml 解析与校验通过")
    print(f"config_hash={config_hash(config)}")
    print(
        "vehicle_counts="
        f"research:{get_config_value(config, 'simulation.num_research_vehicles')},"
        f"SV:{get_config_value(config, 'simulation.num_service_vehicles')},"
        f"TV:{get_config_value(config, 'simulation.num_task_vehicles')}"
    )
    print(f"rsu_count={get_config_value(config, 'nodes.rsu.count')}")
    print(f"uav_count={get_config_value(config, 'nodes.uav.count')}")
    print(f"service_count={get_config_value(config, 'service.count')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
